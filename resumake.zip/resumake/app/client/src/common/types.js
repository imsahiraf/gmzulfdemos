/**
 * @flow
 */

type Section =
  | 'templates'
  | 'profile'
  | 'education'
  | 'work'
  | 'skills'
  | 'projects'
  | 'awards'

export type { Section }
