/**
 * @flow
 */

import Home from './Home'
import Generator from './Generator'
import About from './About'

export { Home, Generator, About }
